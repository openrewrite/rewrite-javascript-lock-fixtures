module.exports = "fresh-pkg@1.1.0"
