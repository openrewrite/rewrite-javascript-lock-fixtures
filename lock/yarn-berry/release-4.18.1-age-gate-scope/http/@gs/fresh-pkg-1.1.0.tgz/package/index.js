module.exports = "@gs/fresh-pkg@1.1.0"
