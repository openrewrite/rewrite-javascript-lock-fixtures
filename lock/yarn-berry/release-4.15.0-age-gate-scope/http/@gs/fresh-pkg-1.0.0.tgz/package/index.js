module.exports = "@gs/fresh-pkg@1.0.0"
