module.exports = "fresh-pkg@1.0.0"
